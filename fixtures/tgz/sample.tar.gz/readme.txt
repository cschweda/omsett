Drop a file. Pick a format.
Nothing leaves your device.

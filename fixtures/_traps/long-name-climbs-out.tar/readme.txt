An ordinary file.

the one that is kept
